"""
Lumora — Flask backend for the eCommerce storefront.

Real backend pieces:
  - SQLite database (via SQLAlchemy) for users, saved addresses, and orders
  - Password hashing + session-based login (see auth.py)
  - Server-side cart & wishlist held in the Flask session (see cart.py)
  - Checkout writes a real Order + OrderItem rows to the database

Product/category data is static Python (data.py) since it's read-only
reference data for this demo — swap it for a Product table whenever you
want an admin panel to manage inventory.
"""

import os
import random
import string
from datetime import datetime

from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session

from data import (
    PRODUCTS, CATEGORIES, get_product_by_slug, get_category_by_slug,
    get_related_products, search_products, discount_percent,
)
from models import db, User, Address, Order, OrderItem
import cart as cart_svc
from auth import get_current_user, login_user, logout_user, login_required

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-secret-change-this-in-production")
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{os.path.join(BASE_DIR, 'lumora.db')}"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db.init_app(app)

with app.app_context():
    db.create_all()


# ---------------------------------------------------------------------------
# Template globals, filters, and per-request context
# ---------------------------------------------------------------------------

@app.context_processor
def inject_globals():
    brands = sorted({p["brand"] for p in PRODUCTS})
    return {
        "nav_categories": CATEGORIES,
        "all_brands": brands,
        "current_user": get_current_user(),
        "cart_items": cart_svc.get_cart(),
        "cart_count": cart_svc.cart_item_count(),
        "cart_totals_ctx": cart_svc.cart_totals(),
        "wishlist_slugs": cart_svc.get_wishlist_slugs(),
        "wishlist_count": len(cart_svc.get_wishlist_slugs()),
    }


@app.template_filter("currency")
def currency_filter(value):
    try:
        return f"${float(value):,.2f}"
    except (TypeError, ValueError):
        return value


@app.template_filter("discount")
def discount_filter(product):
    return discount_percent(product.get("price"), product.get("compare_at_price"))


def generate_order_number():
    return "LUM-" + "".join(random.choices(string.digits, k=6))


# ---------------------------------------------------------------------------
# Core storefront pages
# ---------------------------------------------------------------------------

@app.route("/")
def home():
    bestsellers = [p for p in PRODUCTS if "bestseller" in p.get("tags", [])][:8]
    new_arrivals = [p for p in PRODUCTS if "new" in p.get("tags", [])][:8]
    trending = [p for p in PRODUCTS if "trending" in p.get("tags", [])][:8]
    return render_template(
        "home.html", categories=CATEGORIES,
        bestsellers=bestsellers, new_arrivals=new_arrivals, trending=trending,
    )


@app.route("/shop")
def shop():
    category = request.args.get("category", "")
    tag_filter = request.args.get("filter", "")
    selected_brands = request.args.getlist("brand")
    min_rating = request.args.get("min_rating", type=float, default=0)
    max_price = request.args.get("max_price", type=float)
    sort = request.args.get("sort", "relevance")
    page = request.args.get("page", type=int, default=1)

    products = PRODUCTS
    if category:
        products = [p for p in products if p["category"] == category]
    if tag_filter:
        products = [p for p in products if tag_filter in p.get("tags", [])]
    if selected_brands:
        products = [p for p in products if p["brand"] in selected_brands]
    if min_rating:
        products = [p for p in products if p["rating"] >= min_rating]
    if max_price is not None:
        products = [p for p in products if p["price"] <= max_price]

    if sort == "price-asc":
        products = sorted(products, key=lambda p: p["price"])
    elif sort == "price-desc":
        products = sorted(products, key=lambda p: -p["price"])
    elif sort == "rating":
        products = sorted(products, key=lambda p: -p["rating"])
    elif sort == "newest":
        products = sorted(products, key=lambda p: 0 if "new" in p.get("tags", []) else 1)

    page_size = 8
    total_pages = max(1, (len(products) + page_size - 1) // page_size)
    page = max(1, min(page, total_pages))
    paginated = products[(page - 1) * page_size: page * page_size]

    price_ceiling = max((p.get("compare_at_price") or p["price"]) for p in PRODUCTS)

    return render_template(
        "shop.html",
        products=paginated, total_results=len(products),
        categories=CATEGORIES, brands=sorted({p["brand"] for p in PRODUCTS}),
        active_category=category, selected_brands=selected_brands,
        min_rating=min_rating, max_price=max_price or price_ceiling,
        price_ceiling=price_ceiling, sort=sort,
        page=page, total_pages=total_pages,
    )


@app.route("/product/<slug>")
def product_detail(slug):
    product = get_product_by_slug(slug)
    if not product:
        return render_template("404.html"), 404
    related = get_related_products(product)
    category = get_category_by_slug(product["category"])
    return render_template("product_detail.html", product=product, related=related, category=category)


@app.route("/categories")
def categories():
    return render_template("categories.html", categories=CATEGORIES)


@app.route("/search")
def search():
    query = request.args.get("q", "")
    results = search_products(query)
    return render_template("search.html", query=query, results=results)


@app.route("/api/search-suggestions")
def api_search_suggestions():
    query = request.args.get("q", "").strip().lower()
    if not query:
        return jsonify([])
    titles = set()
    for p in PRODUCTS:
        if query in p["title"].lower():
            titles.add(p["title"])
        if query in p["brand"].lower():
            titles.add(p["brand"])
    return jsonify(sorted(titles)[:6])


# ---------------------------------------------------------------------------
# Wishlist (session-backed)
# ---------------------------------------------------------------------------

@app.route("/wishlist")
def wishlist():
    slugs = cart_svc.get_wishlist_slugs()
    products = [p for p in PRODUCTS if p["slug"] in slugs]
    return render_template("wishlist.html", products=products)


@app.route("/wishlist/toggle", methods=["POST"])
def wishlist_toggle():
    slug = request.form.get("slug")
    is_now_in = cart_svc.toggle_wishlist(slug)
    if request.headers.get("X-Requested-With") == "fetch":
        return jsonify({"wishlisted": is_now_in, "count": len(cart_svc.get_wishlist_slugs())})
    flash("Added to wishlist" if is_now_in else "Removed from wishlist", "success")
    return redirect(request.referrer or url_for("shop"))


# ---------------------------------------------------------------------------
# Cart (session-backed)
# ---------------------------------------------------------------------------

@app.route("/cart")
def view_cart():
    return render_template("cart.html", cart=cart_svc.get_cart(), totals=cart_svc.cart_totals(),
                            coupon=cart_svc.get_coupon())


@app.route("/cart/add", methods=["POST"])
def cart_add():
    slug = request.form.get("slug")
    quantity = request.form.get("quantity", type=int, default=1)
    color = request.form.get("color") or None
    size = request.form.get("size") or None
    ok = cart_svc.add_to_cart(slug, quantity, color, size)
    if request.form.get("buy_now"):
        if not ok:
            flash("Could not add item to cart", "error")
            return redirect(request.referrer or url_for("shop"))
        return redirect(url_for("checkout"))
    flash("Added to cart" if ok else "Could not add item to cart", "success" if ok else "error")
    return redirect(request.referrer or url_for("shop"))


@app.route("/cart/update", methods=["POST"])
def cart_update():
    key = request.form.get("key")
    quantity = request.form.get("quantity", type=int, default=1)
    cart_svc.update_cart_quantity(key, quantity)
    return redirect(url_for("view_cart"))


@app.route("/cart/remove", methods=["POST"])
def cart_remove():
    key = request.form.get("key")
    cart_svc.remove_from_cart(key)
    flash("Item removed from cart", "info")
    return redirect(url_for("view_cart"))


@app.route("/cart/coupon", methods=["POST"])
def cart_coupon():
    action = request.form.get("action")
    if action == "remove":
        cart_svc.remove_coupon()
        flash("Coupon removed", "info")
    else:
        code = request.form.get("code", "")
        if cart_svc.apply_coupon(code):
            flash(f"Coupon \"{code.upper()}\" applied", "success")
        else:
            flash("Invalid coupon code", "error")
    return redirect(url_for("view_cart"))


# ---------------------------------------------------------------------------
# Checkout & Orders (DB-backed, requires login)
# ---------------------------------------------------------------------------

@app.route("/checkout", methods=["GET", "POST"])
@login_required
def checkout():
    user = get_current_user()
    cart = cart_svc.get_cart()
    if not cart:
        flash("Your cart is empty.", "info")
        return redirect(url_for("shop"))

    if request.method == "POST":
        totals = cart_svc.cart_totals()
        coupon_code, _ = cart_svc.get_coupon()
        order = Order(
            order_number=generate_order_number(),
            user_id=user.id,
            status="processing",
            subtotal=totals["subtotal"],
            discount=totals["discount_amount"],
            coupon_code=coupon_code,
            shipping=totals["shipping"],
            tax=totals["tax"],
            total=totals["total"],
            payment_method=request.form.get("payment_method", "card"),
            full_name=request.form.get("full_name", ""),
            address_line1=request.form.get("line1", ""),
            city=request.form.get("city", ""),
            state=request.form.get("state", ""),
            zip_code=request.form.get("zip", ""),
            country=request.form.get("country", ""),
            phone=request.form.get("phone", ""),
        )
        for line in cart:
            order.items.append(OrderItem(
                product_slug=line["slug"], title=line["title"], image=line["image"],
                price=line["price"], quantity=line["quantity"],
                color=line.get("color"), size=line.get("size"),
            ))
        db.session.add(order)
        db.session.commit()

        cart_svc.clear_cart()
        session["last_order_number"] = order.order_number
        return redirect(url_for("order_success"))

    default_address = Address.query.filter_by(user_id=user.id, is_default=True).first()
    return render_template(
        "checkout.html", cart=cart, totals=cart_svc.cart_totals(),
        default_address=default_address,
    )


@app.route("/order-success")
@login_required
def order_success():
    order_number = session.get("last_order_number")
    order = Order.query.filter_by(order_number=order_number, user_id=get_current_user().id).first()
    if not order:
        return redirect(url_for("orders"))
    return render_template("order_success.html", order=order)


@app.route("/orders")
@login_required
def orders():
    user_orders = Order.query.filter_by(user_id=get_current_user().id).order_by(Order.created_at.desc()).all()
    return render_template("orders.html", orders=user_orders)


@app.route("/orders/<order_number>")
@login_required
def order_detail(order_number):
    order = Order.query.filter_by(order_number=order_number, user_id=get_current_user().id).first()
    if not order:
        return render_template("404.html"), 404
    return render_template("order_detail.html", order=order)


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password):
            login_user(user)
            flash(f"Welcome back, {user.name}!", "success")
            next_url = request.args.get("next") or url_for("profile")
            return redirect(next_url)
        flash("Invalid email or password.", "error")
    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")

        error = None
        if len(name) < 2:
            error = "Please enter your full name."
        elif "@" not in email:
            error = "Please enter a valid email address."
        elif len(password) < 6:
            error = "Password must be at least 6 characters."
        elif password != confirm:
            error = "Passwords do not match."
        elif User.query.filter_by(email=email).first():
            error = "An account with this email already exists."

        if error:
            flash(error, "error")
            return render_template("register.html")

        user = User(name=name, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        login_user(user)
        flash("Account created — welcome to Lumora!", "success")
        return redirect(url_for("profile"))

    return render_template("register.html")


@app.route("/logout", methods=["POST"])
def logout():
    logout_user()
    flash("You've been signed out.", "info")
    return redirect(url_for("home"))


@app.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    sent = False
    if request.method == "POST":
        # Demo only: in production this would email a signed reset token.
        sent = True
    return render_template("forgot_password.html", sent=sent, email=request.form.get("email", ""))


# ---------------------------------------------------------------------------
# Account
# ---------------------------------------------------------------------------

@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    user = get_current_user()
    if request.method == "POST":
        form_type = request.form.get("form_type")
        if form_type == "profile":
            user.name = request.form.get("name", user.name).strip()
            user.phone = request.form.get("phone", user.phone)
            db.session.commit()
            flash("Profile updated", "success")
        elif form_type == "add_address":
            is_default = Address.query.filter_by(user_id=user.id).count() == 0
            address = Address(
                user_id=user.id,
                full_name=request.form.get("full_name", ""),
                line1=request.form.get("line1", ""),
                city=request.form.get("city", ""),
                state=request.form.get("state", ""),
                zip_code=request.form.get("zip", ""),
                country=request.form.get("country", ""),
                phone=request.form.get("phone", ""),
                is_default=is_default,
            )
            db.session.add(address)
            db.session.commit()
            flash("Address added", "success")
        return redirect(url_for("profile"))

    addresses = Address.query.filter_by(user_id=user.id).all()
    return render_template("profile.html", user=user, addresses=addresses)


@app.route("/profile/address/<int:address_id>/delete", methods=["POST"])
@login_required
def delete_address(address_id):
    address = Address.query.filter_by(id=address_id, user_id=get_current_user().id).first()
    if address:
        db.session.delete(address)
        db.session.commit()
        flash("Address removed", "info")
    return redirect(url_for("profile"))


@app.route("/settings", methods=["GET", "POST"])
@login_required
def settings():
    user = get_current_user()
    if request.method == "POST":
        form_type = request.form.get("form_type")
        if form_type == "password":
            current = request.form.get("current_password", "")
            new = request.form.get("new_password", "")
            confirm = request.form.get("confirm_password", "")
            if not user.check_password(current):
                flash("Current password is incorrect.", "error")
            elif len(new) < 6:
                flash("New password must be at least 6 characters.", "error")
            elif new != confirm:
                flash("New passwords do not match.", "error")
            else:
                user.set_password(new)
                db.session.commit()
                flash("Password updated", "success")
        elif form_type == "delete_account":
            db.session.delete(user)
            db.session.commit()
            logout_user()
            flash("Your account has been deleted.", "info")
            return redirect(url_for("home"))
        return redirect(url_for("settings"))
    return render_template("settings.html", user=user)


@app.route("/settings/theme", methods=["POST"])
def set_theme():
    theme = request.form.get("theme", "light")
    resp = redirect(request.referrer or url_for("home"))
    resp.set_cookie("theme", theme, max_age=60 * 60 * 24 * 365)
    return resp


# ---------------------------------------------------------------------------
# Content pages
# ---------------------------------------------------------------------------

@app.route("/contact", methods=["GET", "POST"])
def contact():
    if request.method == "POST":
        # Demo only: no email is actually sent. Wire up Flask-Mail or an
        # API (Postmark, SendGrid, etc.) here for a production deployment.
        flash("Message sent — we'll get back to you within 24 hours.", "success")
        return redirect(url_for("contact"))
    return render_template("contact.html")


@app.route("/about")
def about():
    return render_template("about.html")


@app.route("/faq")
def faq():
    return render_template("faq.html")


@app.route("/privacy")
def privacy():
    return render_template("privacy.html")


@app.route("/terms")
def terms():
    return render_template("terms.html")


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------

@app.errorhandler(404)
def not_found(_error):
    return render_template("404.html"), 404


if __name__ == "__main__":
    app.run(debug=True, port=5000)
