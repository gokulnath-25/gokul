/* Checkout: purely visual step switching. All fields live in one <form>
   (see checkout.html) which posts once to Flask on the final "Place Order". */

function ckGoToStep(step) {
  if (step === 2) {
    // Validate step 1's required fields before advancing.
    const step1 = document.querySelector('[data-checkout-step="1"]');
    const inputs = step1.querySelectorAll("input[required]");
    for (const input of inputs) {
      if (!input.reportValidity()) return;
    }
  }

  document.querySelectorAll("[data-checkout-step]").forEach((el) => {
    el.classList.toggle("active", String(step) === el.dataset.checkoutStep);
  });
  document.querySelectorAll("#checkout-stepper .step").forEach((el) => {
    const n = Number(el.dataset.step);
    el.classList.toggle("active", n === step);
    el.classList.toggle("done", n < step);
  });
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function ckSelectPayment(value) {
  document.querySelectorAll("[data-payment-option]").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.paymentOption === value);
  });
  document.getElementById("ck-payment-method").value = value;

  const cardFields = document.getElementById("ck-card-fields");
  if (cardFields) cardFields.style.display = value === "card" ? "grid" : "none";

  const reviewLabel = document.getElementById("ck-review-payment");
  const labelMap = {
    card: "Credit / Debit Card",
    upi: "UPI",
    paypal: "PayPal",
    stripe: "Stripe",
    cod: "Cash on Delivery",
  };
  if (reviewLabel) reviewLabel.textContent = labelMap[value] || value;
}
