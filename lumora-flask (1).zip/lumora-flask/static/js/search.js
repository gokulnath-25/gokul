/* Live search suggestions, powered by GET /api/search-suggestions on the Flask backend. */
document.addEventListener("DOMContentLoaded", () => {
  const input = document.getElementById("live-search-input");
  const box = document.getElementById("live-search-suggestions");
  if (!input || !box) return;

  let debounceTimer;
  input.addEventListener("input", () => {
    clearTimeout(debounceTimer);
    const query = input.value.trim();
    if (!query) {
      box.style.display = "none";
      return;
    }
    debounceTimer = setTimeout(() => fetchSuggestions(query), 200);
  });

  input.addEventListener("blur", () => {
    setTimeout(() => (box.style.display = "none"), 150);
  });

  async function fetchSuggestions(query) {
    try {
      const res = await fetch(`/api/search-suggestions?q=${encodeURIComponent(query)}`);
      const suggestions = await res.json();
      if (!suggestions.length) {
        box.style.display = "none";
        return;
      }
      box.innerHTML = suggestions
        .map(
          (s) =>
            `<button type="button" style="display:block;width:100%;text-align:left;border-radius:0.75rem;padding:0.625rem 0.75rem;font-size:0.875rem;background:none;border:none;color:rgb(var(--color-ink));" onclick="window.location.href='/search?q=${encodeURIComponent(
              s
            )}'">${s}</button>`
        )
        .join("");
      box.style.display = "block";
    } catch (err) {
      box.style.display = "none";
    }
  }
});
