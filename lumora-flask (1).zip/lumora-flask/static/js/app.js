/* =========================================================
   Lumora — Core frontend interactions
   (Cart/wishlist/checkout/auth are handled server-side by Flask;
    this file only handles client-side UI: drawers, dropdowns,
    the theme toggle, toasts, tabs, and the hero slider.)
   ========================================================= */

document.addEventListener("DOMContentLoaded", () => {
  initNavbarScroll();
  initDropdowns();
  initSearchToggle();
  initTheme();
  initCartDrawer();
  initMobileMenu();
  initMobileFilters();
  initFooterYear();
  initNewsletterForm();
  initFlashToasts();
  initHeroSlider();
  initFeaturedTabs();
  initProductDetailTabs();
  initProfileTabs();
});

/* ---------- Navbar scroll shadow ---------- */
function initNavbarScroll() {
  const navbar = document.getElementById("navbar");
  if (!navbar) return;
  window.addEventListener("scroll", () => {
    navbar.classList.toggle("scrolled", window.scrollY > 8);
  });
}

/* ---------- Generic dropdowns (browse menu, user menu, sort menu) ---------- */
function initDropdowns() {
  const dropdowns = document.querySelectorAll("[data-dropdown]");
  dropdowns.forEach((dropdown) => {
    const trigger = dropdown.querySelector("[data-dropdown-trigger]");
    if (!trigger) return;
    trigger.addEventListener("click", (e) => {
      e.stopPropagation();
      const isOpen = dropdown.classList.contains("open");
      dropdowns.forEach((d) => d.classList.remove("open"));
      if (!isOpen) dropdown.classList.add("open");
    });
  });
  document.addEventListener("click", () => {
    dropdowns.forEach((d) => d.classList.remove("open"));
  });
}

/* ---------- Search bar toggle ---------- */
function initSearchToggle() {
  const wrap = document.querySelector("[data-search]");
  if (!wrap) return;
  const trigger = wrap.querySelector("[data-search-trigger]");
  const form = wrap.querySelector("[data-search-form]");
  trigger.addEventListener("click", () => {
    form.classList.toggle("open");
    if (form.classList.contains("open")) form.querySelector("input").focus();
  });
  document.addEventListener("click", (e) => {
    if (!wrap.contains(e.target)) form.classList.remove("open");
  });
}

/* ---------- Theme toggle (light/dark), persisted via cookie ---------- */
function initTheme() {
  const btn = document.getElementById("theme-toggle");
  const sunIcon = document.getElementById("theme-icon-sun");
  const moonIcon = document.getElementById("theme-icon-moon");

  function reflect() {
    const current = document.documentElement.getAttribute("data-theme") || "light";
    if (sunIcon && moonIcon) {
      sunIcon.classList.toggle("hidden", current === "dark");
      moonIcon.classList.toggle("hidden", current !== "dark");
    }
  }
  reflect();

  if (!btn) return;
  btn.addEventListener("click", () => {
    const current = document.documentElement.getAttribute("data-theme") || "light";
    const next = current === "light" ? "dark" : "light";
    document.documentElement.setAttribute("data-theme", next);
    document.cookie = `theme=${next};max-age=${60 * 60 * 24 * 365};path=/`;
    reflect();
  });
}

/* ---------- Cart drawer ---------- */
function initCartDrawer() {
  const trigger = document.getElementById("cart-trigger");
  const overlay = document.getElementById("cart-drawer-overlay");
  const close = document.getElementById("cart-drawer-close");
  if (!trigger || !overlay) return;

  trigger.addEventListener("click", () => overlay.classList.add("open"));
  close?.addEventListener("click", () => overlay.classList.remove("open"));
  overlay.addEventListener("click", (e) => {
    if (e.target === overlay) overlay.classList.remove("open");
  });
}

/* ---------- Mobile nav menu ---------- */
function initMobileMenu() {
  const trigger = document.getElementById("mobile-menu-trigger");
  const overlay = document.getElementById("mobile-menu-overlay");
  const close = document.getElementById("mobile-menu-close");
  if (!trigger || !overlay) return;

  trigger.addEventListener("click", () => overlay.classList.add("open"));
  close?.addEventListener("click", () => overlay.classList.remove("open"));
  overlay.addEventListener("click", (e) => {
    if (e.target === overlay) overlay.classList.remove("open");
  });
}

/* ---------- Mobile filters drawer (shop page) ---------- */
function initMobileFilters() {
  const trigger = document.getElementById("mobile-filters-trigger");
  const overlay = document.getElementById("mobile-filters-overlay");
  const close = document.getElementById("mobile-filters-close");
  if (!trigger || !overlay) return;

  trigger.addEventListener("click", () => overlay.classList.add("open"));
  close?.addEventListener("click", () => overlay.classList.remove("open"));
  overlay.addEventListener("click", (e) => {
    if (e.target === overlay) overlay.classList.remove("open");
  });
}

/* ---------- Footer year ---------- */
function initFooterYear() {
  const el = document.getElementById("footer-year");
  if (el) el.textContent = new Date().getFullYear();
}

/* ---------- Newsletter (demo only — no backend endpoint) ---------- */
function initNewsletterForm() {
  const form = document.getElementById("newsletter-form");
  if (!form) return;
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    showToast("Subscribed! Check your inbox for a welcome offer.", "success");
    form.reset();
  });
}

/* ---------- Toasts ---------- */
function showToast(message, type = "success") {
  const container = document.getElementById("toast-container");
  if (!container) return;
  const icons = {
    success: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>',
    error: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>',
    info: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>',
  };
  const toast = document.createElement("div");
  toast.className = "toast glass-strong";
  toast.innerHTML = `
    <span class="toast-icon ${type}">${icons[type] || icons.info}</span>
    <p>${message}</p>
    <button class="toast-close" aria-label="Dismiss">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
    </button>`;
  toast.querySelector(".toast-close").addEventListener("click", () => toast.remove());
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 3800);
}

function initFlashToasts() {
  if (!window.__flashMessages) return;
  window.__flashMessages.forEach(([category, message], i) => {
    const type = category === "error" ? "error" : category === "info" ? "info" : "success";
    setTimeout(() => showToast(message, type), i * 150);
  });
}

/* ---------- Hero slider (home page) ---------- */
function initHeroSlider() {
  const root = document.getElementById("hero-slider");
  if (!root) return;
  const slides = root.querySelectorAll("[data-slide]");
  const dots = root.querySelectorAll("[data-slide-dot]");
  if (slides.length < 2) return;
  let index = 0;
  let timer = setInterval(next, 5500);

  function show(i) {
    slides.forEach((s, si) => (s.style.display = si === i ? "grid" : "none"));
    dots.forEach((d, di) => d.classList.toggle("active", di === i));
    index = i;
  }
  function next() {
    show((index + 1) % slides.length);
  }
  dots.forEach((dot, i) => {
    dot.addEventListener("click", () => {
      clearInterval(timer);
      show(i);
      timer = setInterval(next, 5500);
    });
  });
}

/* ---------- Featured products tabs (home page) ---------- */
function initFeaturedTabs() {
  const tabs = document.querySelectorAll("[data-featured-tab]");
  if (!tabs.length) return;
  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      const key = tab.dataset.featuredTab;
      tabs.forEach((t) => t.classList.toggle("active", t === tab));
      document.querySelectorAll("[data-featured-panel]").forEach((panel) => {
        panel.style.display = panel.dataset.featuredPanel === key ? "grid" : "none";
      });
    });
  });
}

/* ---------- Product detail tabs (specs / reviews) ---------- */
function initProductDetailTabs() {
  const tabs = document.querySelectorAll("[data-pd-tab]");
  if (!tabs.length) return;
  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      const key = tab.dataset.pdTab;
      tabs.forEach((t) => t.classList.toggle("active", t === tab));
      document.querySelectorAll("[data-pd-panel]").forEach((panel) => {
        panel.classList.toggle("active", panel.dataset.pdPanel === key);
      });
    });
  });
}

/* ---------- Profile page tabs ---------- */
function initProfileTabs() {
  const tabs = document.querySelectorAll("[data-profile-tab]");
  if (!tabs.length) return;
  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      const key = tab.dataset.profileTab;
      tabs.forEach((t) => t.classList.toggle("active", t === tab));
      document.querySelectorAll("[data-profile-panel]").forEach((panel) => {
        panel.classList.toggle("active", panel.dataset.profilePanel === key);
      });
    });
  });
}
