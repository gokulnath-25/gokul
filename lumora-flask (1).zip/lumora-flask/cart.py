"""
Server-side cart & wishlist, backed by the Flask session (a signed cookie).

This means the cart survives page reloads and works without requiring
login (like any real storefront), while still being handled entirely by
the backend — no client-side localStorage involved. If you want carts to
persist across devices, swap this for a CartItem DB table keyed by user_id
and merge the session cart into it on login.
"""

from flask import session
from data import get_product_by_slug

COUPONS = {"WELCOME10": 10, "LUMORA20": 20, "FREESHIP": 5}
TAX_RATE = 0.08
FREE_SHIPPING_THRESHOLD = 75
SHIPPING_FLAT_RATE = 9.99


def _line_key(slug, color, size):
    return f"{slug}::{color or ''}::{size or ''}"


def get_cart():
    return session.get("cart", [])


def save_cart(cart):
    session["cart"] = cart
    session.modified = True


def add_to_cart(slug, quantity=1, color=None, size=None):
    product = get_product_by_slug(slug)
    if not product:
        return False

    cart = get_cart()
    key = _line_key(slug, color, size)
    for line in cart:
        if line["key"] == key:
            line["quantity"] = min(line["quantity"] + quantity, product["stock"])
            save_cart(cart)
            return True

    cart.append({
        "key": key,
        "slug": slug,
        "title": product["title"],
        "image": product["images"][0],
        "price": product["price"],
        "quantity": min(quantity, product["stock"]),
        "color": color,
        "size": size,
        "stock": product["stock"],
    })
    save_cart(cart)
    return True


def update_cart_quantity(key, quantity):
    cart = get_cart()
    for line in cart:
        if line["key"] == key:
            line["quantity"] = max(1, min(quantity, line["stock"]))
    save_cart(cart)


def remove_from_cart(key):
    cart = [line for line in get_cart() if line["key"] != key]
    save_cart(cart)


def clear_cart():
    session["cart"] = []
    session.pop("coupon_code", None)
    session.modified = True


def cart_item_count():
    return sum(line["quantity"] for line in get_cart())


def cart_subtotal():
    return sum(line["price"] * line["quantity"] for line in get_cart())


def apply_coupon(code):
    normalized = (code or "").strip().upper()
    if normalized in COUPONS:
        session["coupon_code"] = normalized
        session.modified = True
        return True
    return False


def remove_coupon():
    session.pop("coupon_code", None)
    session.modified = True


def get_coupon():
    code = session.get("coupon_code")
    return (code, COUPONS[code]) if code in COUPONS else (None, 0)


def cart_totals():
    subtotal = cart_subtotal()
    _, discount_pct = get_coupon()
    discount_amount = subtotal * discount_pct / 100
    shipping = 0 if subtotal == 0 or subtotal >= FREE_SHIPPING_THRESHOLD else SHIPPING_FLAT_RATE
    tax = (subtotal - discount_amount) * TAX_RATE
    total = subtotal - discount_amount + shipping + tax
    return {
        "subtotal": subtotal,
        "discount_pct": discount_pct,
        "discount_amount": discount_amount,
        "shipping": shipping,
        "tax": tax,
        "total": total,
        "free_shipping_threshold": FREE_SHIPPING_THRESHOLD,
    }


# --- Wishlist -----------------------------------------------------------

def get_wishlist_slugs():
    return session.get("wishlist", [])


def toggle_wishlist(slug):
    wishlist = get_wishlist_slugs()
    if slug in wishlist:
        wishlist.remove(slug)
    else:
        wishlist.append(slug)
    session["wishlist"] = wishlist
    session.modified = True
    return slug in wishlist
