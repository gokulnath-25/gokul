# Lumora — Flask eCommerce Backend

A full-stack rebuild of the Lumora storefront: plain **HTML + CSS + JavaScript**
on the frontend, rendered server-side by a real **Python Flask** backend with a
**SQLite database** (via SQLAlchemy) for users, addresses, and orders.

## What's "real backend" here

- **Database (SQLite via SQLAlchemy)** — `models.py` defines `User`, `Address`,
  `Order`, `OrderItem`. Created automatically on first run as `lumora.db`.
- **Authentication** — passwords are hashed with Werkzeug's
  `generate_password_hash`/`check_password_hash` (never stored in plain text);
  login state lives in a signed Flask session cookie (`auth.py`).
- **Checkout** — writes a real `Order` + `OrderItem` rows to the database.
  Order history and order detail pages query the DB for the logged-in user.
- **Cart & wishlist** — held server-side in the Flask session (`cart.py`), so
  they work without login (like a real storefront) and survive page reloads,
  without any client-side localStorage.
- **Forms post to real routes** — add-to-cart, quantity updates, coupon codes,
  wishlist toggling, login/register, address book, and checkout are all
  handled by Flask routes in `app.py`, not JavaScript pretending to be a backend.

JavaScript in `static/js/` is intentionally thin — it only handles pure UI
(dropdowns, drawers, the theme toggle, tab switching, the hero slider, and the
live search-suggestions fetch call). Every state-changing action is a real
HTTP request to Flask.

## Getting Started

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open **http://localhost:5000**. A `lumora.db` SQLite file is created
automatically on first run — no manual migration step needed.

## Project Structure

```
lumora-flask/
├─ app.py                  # All routes, context processors, template filters
├─ models.py                # SQLAlchemy models: User, Address, Order, OrderItem
├─ cart.py                  # Session-backed cart + wishlist logic, coupons, totals
├─ auth.py                  # Password auth helpers + @login_required decorator
├─ data.py                  # Static product/category catalog (read-only demo data)
├─ requirements.txt
├─ templates/
│  ├─ base.html             # <head>, navbar/footer includes, flash→toast bridge
│  ├─ home.html, shop.html, product_detail.html, categories.html, search.html
│  ├─ wishlist.html, cart.html, checkout.html, order_success.html, orders.html, order_detail.html
│  ├─ login.html, register.html, forgot_password.html
│  ├─ profile.html, settings.html
│  ├─ contact.html, about.html, faq.html, privacy.html, terms.html
│  ├─ 404.html
│  └─ partials/
│     ├─ icons.html         # Feather-style inline SVG icon macros
│     ├─ navbar.html, footer.html, cart_drawer.html, mobile_menu.html
│     ├─ product_card.html  # Reusable product card + rating macros
│     ├─ filter_form.html   # Shop page filter sidebar (GET form)
│     └─ auth_shell.html    # Shared split-screen layout for login/register/forgot
└─ static/
   ├─ css/style.css          # Design tokens, resets, glassmorphism utilities
   ├─ css/components.css     # Buttons, badges, forms, modals, drawers, tabs...
   ├─ css/layout.css         # Navbar, hero, product grid, page-specific layouts
   └─ js/
      ├─ app.js              # Navbar, drawers, dropdowns, theme, toasts, tabs, hero slider
      ├─ search.js           # Live search suggestions (fetches /api/search-suggestions)
      └─ checkout.js         # Visual step switching + payment method selection
```

## Routes at a glance

| Route | Method(s) | What it does |
|---|---|---|
| `/` | GET | Home page |
| `/shop` | GET | Filter/sort/paginate the catalog (query params) |
| `/product/<slug>` | GET | Product detail |
| `/search` | GET | Search results; `/api/search-suggestions` powers the live dropdown |
| `/wishlist`, `/wishlist/toggle` | GET, POST | Session-backed wishlist |
| `/cart`, `/cart/add`, `/cart/update`, `/cart/remove`, `/cart/coupon` | GET, POST | Session-backed cart |
| `/checkout` | GET, POST | **Requires login.** POST creates a DB `Order` |
| `/orders`, `/orders/<order_number>` | GET | **Requires login.** Reads the user's orders from the DB |
| `/login`, `/register`, `/logout`, `/forgot-password` | GET, POST | Session auth against the `users` table |
| `/profile`, `/settings` | GET, POST | **Requires login.** Edit profile, addresses, password; delete account |
| `/contact`, `/about`, `/faq`, `/privacy`, `/terms` | GET (+POST for contact) | Static content pages |

## Test coupon codes

`WELCOME10` (10% off), `LUMORA20` (20% off), `FREESHIP` (5% off) — applied at `/cart`.

## Extending this for production

- Swap `data.py` for a `Product`/`Category` table + an admin panel if you want
  to manage inventory without editing code.
- Wire up `/contact`'s POST handler to an actual email provider (Flask-Mail,
  Postmark, SendGrid, etc.) — right now it just flashes a success message.
- Add real payment processing (Stripe/PayPal SDKs) in the checkout POST
  handler — right now payment method is stored but never actually charged.
- Move `SECRET_KEY` and the SQLite path into environment variables /
  a proper config class before deploying (a placeholder default is used here).
- Consider Flask-WTF for CSRF protection on forms if deploying publicly.
