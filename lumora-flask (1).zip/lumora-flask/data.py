"""
Dummy catalog data for the Lumora storefront.
In a real app this would come from a database — here it's plain Python
data structures so the Flask routes have something to render.
"""

CATEGORIES = [
    {
        "id": "cat-1", "slug": "audio", "name": "Audio", "icon": "headphones",
        "image": "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=800&auto=format&fit=crop",
        "product_count": 2,
    },
    {
        "id": "cat-2", "slug": "wearables", "name": "Wearables", "icon": "watch",
        "image": "https://images.unsplash.com/photo-1523275335684-37898b6baf30?q=80&w=800&auto=format&fit=crop",
        "product_count": 2,
    },
    {
        "id": "cat-3", "slug": "computing", "name": "Computing", "icon": "laptop",
        "image": "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?q=80&w=800&auto=format&fit=crop",
        "product_count": 3,
    },
    {
        "id": "cat-4", "slug": "photography", "name": "Photography", "icon": "camera",
        "image": "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?q=80&w=800&auto=format&fit=crop",
        "product_count": 1,
    },
    {
        "id": "cat-5", "slug": "footwear", "name": "Footwear", "icon": "shoe",
        "image": "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?q=80&w=800&auto=format&fit=crop",
        "product_count": 2,
    },
    {
        "id": "cat-6", "slug": "home", "name": "Home & Living", "icon": "home",
        "image": "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?q=80&w=800&auto=format&fit=crop",
        "product_count": 2,
    },
]


def _reviews(seed):
    return [
        {
            "id": f"{seed}-r1", "author": "Amelia H.", "rating": 5,
            "title": "Exceeded expectations",
            "comment": "The build quality is fantastic and it feels far more premium than the price suggests. Shipping was quick too.",
            "date": "2026-06-02", "verified": True,
        },
        {
            "id": f"{seed}-r2", "author": "Jordan P.", "rating": 4,
            "title": "Great value",
            "comment": "Does everything I need. Only minor gripe is the packaging, but the product itself is excellent.",
            "date": "2026-05-18", "verified": True,
        },
        {
            "id": f"{seed}-r3", "author": "Sana K.", "rating": 5,
            "title": "Would buy again",
            "comment": "Second purchase from this brand and it's consistently reliable. Highly recommend to anyone on the fence.",
            "date": "2026-04-27", "verified": False,
        },
    ]


PRODUCTS = [
    {
        "id": "p-1", "slug": "aria-wireless-headphones", "title": "Aria Wireless Noise-Cancelling Headphones",
        "brand": "Nordwave", "category": "audio", "price": 249, "compare_at_price": 329,
        "rating": 4.7, "review_count": 312,
        "images": [
            "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=1200&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1583394838336-acd977736f90?q=80&w=1200&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1546435770-a3e426bf472b?q=80&w=1200&auto=format&fit=crop",
        ],
        "colors": [{"name": "Midnight", "hex": "#1c1c26"}, {"name": "Pearl", "hex": "#e9e6df"}, {"name": "Rosewood", "hex": "#8a4b4b"}],
        "sizes": [],
        "description": "Aria wraps studio-grade sound in a featherlight shell. Adaptive noise cancellation reads your environment in real time, while 40-hour battery life keeps the music going for days, not hours.",
        "specifications": {"Driver Size": "40mm Dynamic", "Battery Life": "Up to 40 hours (ANC on)", "Connectivity": "Bluetooth 5.3, USB-C", "Weight": "254g", "Charging Time": "1.5 hours full charge"},
        "stock": 24, "tags": ["bestseller", "trending"], "reviews": _reviews("p-1"),
    },
    {
        "id": "p-2", "slug": "pulse-true-wireless-earbuds", "title": "Pulse True Wireless Earbuds",
        "brand": "Nordwave", "category": "audio", "price": 129, "compare_at_price": 159,
        "rating": 4.5, "review_count": 208,
        "images": [
            "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?q=80&w=1200&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?q=80&w=1200&auto=format&fit=crop",
        ],
        "colors": [{"name": "Onyx", "hex": "#111114"}, {"name": "Snow", "hex": "#f4f4f4"}],
        "sizes": [],
        "description": "Compact earbuds tuned for all-day comfort. Sweat resistant, quick-pairing, and packed into a pocketable charging case good for three extra charges.",
        "specifications": {"Battery Life": "8h (28h with case)", "Connectivity": "Bluetooth 5.2", "Water Resistance": "IPX5", "Weight": "4.8g per earbud"},
        "stock": 41, "tags": ["new"], "reviews": _reviews("p-2"),
    },
    {
        "id": "p-3", "slug": "chrono-smartwatch-se", "title": "Chrono Smartwatch SE",
        "brand": "Fielder", "category": "wearables", "price": 219, "compare_at_price": 259,
        "rating": 4.6, "review_count": 176,
        "images": [
            "https://images.unsplash.com/photo-1523275335684-37898b6baf30?q=80&w=1200&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1544117519-31a4b719223d?q=80&w=1200&auto=format&fit=crop",
        ],
        "colors": [{"name": "Graphite", "hex": "#3a3a3f"}, {"name": "Sand", "hex": "#cbb89d"}],
        "sizes": ["40mm", "44mm"],
        "description": "Track workouts, sleep, and heart rate with a display crisp enough for direct sunlight. Seven-day battery life means fewer trips back to the charger.",
        "specifications": {"Display": "1.9in AMOLED, 450 nits", "Battery Life": "Up to 7 days", "Water Resistance": "5 ATM", "Sensors": "Heart rate, SpO2, GPS"},
        "stock": 18, "tags": ["bestseller"], "reviews": _reviews("p-3"),
    },
    {
        "id": "p-4", "slug": "vector-14-ultrabook", "title": "Vector 14 Ultrabook",
        "brand": "Halcyon", "category": "computing", "price": 1349, "compare_at_price": 1499,
        "rating": 4.8, "review_count": 94,
        "images": [
            "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?q=80&w=1200&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?q=80&w=1200&auto=format&fit=crop",
        ],
        "colors": [{"name": "Silver", "hex": "#c9cbcf"}, {"name": "Space Grey", "hex": "#4a4c52"}],
        "sizes": [],
        "description": "A 14-inch ultrabook milled from a single block of aluminum. Fanless design, all-day battery, and a display color-accurate enough for creative work.",
        "specifications": {"Processor": "12-core, 3.4GHz", "Memory": "16GB unified", "Storage": "512GB SSD", "Display": "14.2in Liquid Retina, 120Hz", "Battery": "Up to 18 hours"},
        "stock": 9, "tags": ["trending"], "reviews": _reviews("p-4"),
    },
    {
        "id": "p-5", "slug": "tab-air-11", "title": "Tab Air 11",
        "brand": "Halcyon", "category": "computing", "price": 599, "compare_at_price": None,
        "rating": 4.4, "review_count": 152,
        "images": [
            "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?q=80&w=1200&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1561154464-82e9adf32764?q=80&w=1200&auto=format&fit=crop",
        ],
        "colors": [{"name": "Starlight", "hex": "#e7e2d8"}, {"name": "Midnight", "hex": "#20222b"}],
        "sizes": ["64GB", "256GB"],
        "description": "Thin, light, and fast enough for full creative workflows. Paired with an optional stylus for sketching, marking up documents, or taking handwritten notes.",
        "specifications": {"Display": "11in Liquid Retina", "Chip": "8-core Neural chip", "Weight": "460g", "Battery": "Up to 10 hours"},
        "stock": 33, "tags": [], "reviews": _reviews("p-5"),
    },
    {
        "id": "p-6", "slug": "frame-x-mirrorless-camera", "title": "Frame X Mirrorless Camera",
        "brand": "Lucent", "category": "photography", "price": 1899, "compare_at_price": 2099,
        "rating": 4.9, "review_count": 61,
        "images": [
            "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?q=80&w=1200&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?q=80&w=1200&auto=format&fit=crop",
        ],
        "colors": [{"name": "Black", "hex": "#111111"}],
        "sizes": [],
        "description": "A full-frame mirrorless body built for both stills and video. In-body stabilization and a stacked sensor make it equally at home on a tripod or in your hands.",
        "specifications": {"Sensor": "33MP full-frame stacked", "Video": "6K/30p, 4K/120p", "Stabilization": "5-axis IBIS, 8 stops", "Viewfinder": "9.44M-dot EVF"},
        "stock": 6, "tags": ["new"], "reviews": _reviews("p-6"),
    },
    {
        "id": "p-7", "slug": "pathfinder-running-shoes", "title": "Pathfinder Running Shoes",
        "brand": "Terraform", "category": "footwear", "price": 139, "compare_at_price": 169,
        "rating": 4.5, "review_count": 421,
        "images": [
            "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?q=80&w=1200&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=1200&auto=format&fit=crop",
        ],
        "colors": [{"name": "Cloud", "hex": "#e9e9ec"}, {"name": "Ember", "hex": "#c5502f"}],
        "sizes": ["7", "8", "9", "10", "11", "12"],
        "description": "Responsive foam and a breathable knit upper built for daily miles. Engineered outsole grips wet pavement and loose trail alike.",
        "specifications": {"Upper Material": "Engineered knit mesh", "Midsole": "Dual-density foam", "Drop": "8mm", "Weight": "252g (size 9)"},
        "stock": 57, "tags": ["bestseller", "trending"], "reviews": _reviews("p-7"),
    },
    {
        "id": "p-8", "slug": "summit-trail-boots", "title": "Summit Trail Boots",
        "brand": "Terraform", "category": "footwear", "price": 179, "compare_at_price": None,
        "rating": 4.6, "review_count": 134,
        "images": [
            "https://images.unsplash.com/photo-1542838132-92c53300491e?q=80&w=1200&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1520639888713-7851133b1ed0?q=80&w=1200&auto=format&fit=crop",
        ],
        "colors": [{"name": "Moss", "hex": "#4d5a41"}, {"name": "Clay", "hex": "#8c5a3c"}],
        "sizes": ["7", "8", "9", "10", "11"],
        "description": "Waterproof leather uppers and an aggressive lug outsole for technical terrain. Broken in from the first mile, not the fiftieth.",
        "specifications": {"Upper": "Waterproof nubuck leather", "Outsole": "Vibram rubber lugs", "Weight": "410g (size 9)"},
        "stock": 22, "tags": [], "reviews": _reviews("p-8"),
    },
    {
        "id": "p-9", "slug": "hearth-ceramic-diffuser", "title": "Hearth Ceramic Diffuser",
        "brand": "Solace", "category": "home", "price": 68, "compare_at_price": None,
        "rating": 4.3, "review_count": 87,
        "images": [
            "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?q=80&w=1200&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1602874801007-a3b2ac1a3b1b?q=80&w=1200&auto=format&fit=crop",
        ],
        "colors": [{"name": "Sand", "hex": "#dccdb8"}, {"name": "Charcoal", "hex": "#3c3c3c"}],
        "sizes": [],
        "description": "Hand-finished ceramic housing with a whisper-quiet ultrasonic core. Timed misting cycles run up to ten hours on a single fill.",
        "specifications": {"Capacity": "300ml", "Run Time": "Up to 10 hours", "Noise Level": "<28dB"},
        "stock": 45, "tags": [], "reviews": _reviews("p-9"),
    },
    {
        "id": "p-10", "slug": "loom-weighted-throw", "title": "Loom Weighted Throw Blanket",
        "brand": "Solace", "category": "home", "price": 89, "compare_at_price": 110,
        "rating": 4.7, "review_count": 203,
        "images": [
            "https://images.unsplash.com/photo-1580301762395-83f8ca871bbc?q=80&w=1200&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?q=80&w=1200&auto=format&fit=crop",
        ],
        "colors": [{"name": "Oat", "hex": "#e4dccb"}, {"name": "Slate", "hex": "#5b6470"}],
        "sizes": ["5 lb", "10 lb", "15 lb"],
        "description": "Glass-bead fill distributed through a quilted cotton shell for even, calming pressure. Machine washable cover included.",
        "specifications": {"Material": "Cotton shell, glass bead fill", "Care": "Removable, machine-washable cover"},
        "stock": 39, "tags": ["trending"], "reviews": _reviews("p-10"),
    },
    {
        "id": "p-11", "slug": "cadence-fitness-band", "title": "Cadence Fitness Band",
        "brand": "Fielder", "category": "wearables", "price": 79, "compare_at_price": None,
        "rating": 4.2, "review_count": 268,
        "images": [
            "https://images.unsplash.com/photo-1575311373937-8f0c2b1a5c6a?q=80&w=1200&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?q=80&w=1200&auto=format&fit=crop",
        ],
        "colors": [{"name": "Black", "hex": "#161616"}, {"name": "Coral", "hex": "#ff5a5f"}],
        "sizes": [],
        "description": "A slim, all-day fitness band with two-week battery life. Tracks steps, sleep stages, and heart rate without ever asking to be charged mid-week.",
        "specifications": {"Battery": "Up to 14 days", "Water Resistance": "5 ATM", "Display": "AMOLED touch"},
        "stock": 62, "tags": ["new"], "reviews": _reviews("p-11"),
    },
    {
        "id": "p-12", "slug": "keystone-mechanical-keyboard", "title": "Keystone Mechanical Keyboard",
        "brand": "Halcyon", "category": "computing", "price": 159, "compare_at_price": 189,
        "rating": 4.8, "review_count": 145,
        "images": [
            "https://images.unsplash.com/photo-1587829741301-dc798b83add3?q=80&w=1200&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1595225476474-89731ff5a09b?q=80&w=1200&auto=format&fit=crop",
        ],
        "colors": [{"name": "Ivory", "hex": "#f1ede4"}, {"name": "Graphite", "hex": "#33343a"}],
        "sizes": [],
        "description": "Hot-swappable switches, a gasket-mounted plate, and per-key RGB in an 75% layout built for both typing and late-night sessions.",
        "specifications": {"Layout": "75%, hot-swappable", "Connectivity": "USB-C, Bluetooth 5.1", "Switches": "Tactile, 45g actuation"},
        "stock": 28, "tags": ["bestseller"], "reviews": _reviews("p-12"),
    },
]


def get_product_by_slug(slug):
    return next((p for p in PRODUCTS if p["slug"] == slug), None)


def get_category_by_slug(slug):
    return next((c for c in CATEGORIES if c["slug"] == slug), None)


def get_related_products(product, limit=4):
    return [p for p in PRODUCTS if p["category"] == product["category"] and p["id"] != product["id"]][:limit]


def search_products(query):
    q = (query or "").strip().lower()
    if not q:
        return []
    results = []
    for p in PRODUCTS:
        haystack = " ".join([p["title"], p["brand"], p["category"], " ".join(p.get("tags", []))]).lower()
        if q in haystack:
            results.append(p)
    return results


def discount_percent(price, compare_at_price):
    if not compare_at_price or compare_at_price <= price:
        return 0
    return round(((compare_at_price - price) / compare_at_price) * 100)
