"""
Database models for the Lumora backend.

Only the things that genuinely need persistence live here: users, their
saved addresses, and the orders they place. The product catalog stays as
plain Python data in data.py (it's read-only reference data, not something
users create) — swap it for a Product model + migration later if you want
an admin panel to manage inventory.
"""

from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    phone = db.Column(db.String(30))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    addresses = db.relationship(
        "Address", backref="user", cascade="all, delete-orphan", lazy=True
    )
    orders = db.relationship(
        "Order", backref="user", cascade="all, delete-orphan", lazy=True,
        order_by="desc(Order.created_at)",
    )

    def set_password(self, raw_password):
        self.password_hash = generate_password_hash(raw_password)

    def check_password(self, raw_password):
        return check_password_hash(self.password_hash, raw_password)

    def to_dict(self):
        return {"id": self.id, "name": self.name, "email": self.email, "phone": self.phone}


class Address(db.Model):
    __tablename__ = "addresses"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    full_name = db.Column(db.String(120), nullable=False)
    line1 = db.Column(db.String(255), nullable=False)
    city = db.Column(db.String(120), nullable=False)
    state = db.Column(db.String(120), nullable=False)
    zip_code = db.Column(db.String(20), nullable=False)
    country = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(30), nullable=False)
    is_default = db.Column(db.Boolean, default=False)


class Order(db.Model):
    __tablename__ = "orders"

    id = db.Column(db.Integer, primary_key=True)
    order_number = db.Column(db.String(20), unique=True, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    status = db.Column(db.String(20), default="processing")  # processing/shipped/delivered/cancelled

    subtotal = db.Column(db.Float, nullable=False)
    discount = db.Column(db.Float, default=0)
    coupon_code = db.Column(db.String(30))
    shipping = db.Column(db.Float, default=0)
    tax = db.Column(db.Float, default=0)
    total = db.Column(db.Float, nullable=False)

    payment_method = db.Column(db.String(30), nullable=False)
    full_name = db.Column(db.String(120), nullable=False)
    address_line1 = db.Column(db.String(255), nullable=False)
    city = db.Column(db.String(120), nullable=False)
    state = db.Column(db.String(120), nullable=False)
    zip_code = db.Column(db.String(20), nullable=False)
    country = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(30), nullable=False)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    items = db.relationship("OrderItem", backref="order", cascade="all, delete-orphan", lazy=True)


class OrderItem(db.Model):
    __tablename__ = "order_items"

    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey("orders.id"), nullable=False)
    product_slug = db.Column(db.String(150), nullable=False)
    title = db.Column(db.String(255), nullable=False)
    image = db.Column(db.String(500))
    price = db.Column(db.Float, nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    color = db.Column(db.String(50))
    size = db.Column(db.String(50))

    @property
    def line_total(self):
        return self.price * self.quantity
