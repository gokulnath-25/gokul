"""
Lightweight session-based authentication (no Flask-Login dependency —
just the signed Flask session cookie storing the logged-in user's id).
"""

from functools import wraps
from flask import session, redirect, url_for, request, flash
from models import User


def get_current_user():
    user_id = session.get("user_id")
    if not user_id:
        return None
    return User.query.get(user_id)


def login_user(user):
    session["user_id"] = user.id
    session.permanent = True


def logout_user():
    session.pop("user_id", None)


def login_required(view_func):
    @wraps(view_func)
    def wrapped(*args, **kwargs):
        if not session.get("user_id"):
            flash("Please sign in to continue.", "info")
            return redirect(url_for("login", next=request.path))
        return view_func(*args, **kwargs)
    return wrapped
